#!/bin/sh
PoolHost=
Port=
PublicVerusCoinAddress=RNSiKHbkRn1vLTD5sDE4Ra84qt3vfZtCeU
WorkerName=ali
Threads=
#set working directory to the location of this script
DIR="$( cd "$( dirname "${BASH_SOURCE[0]}" )" && pwd )"
cd $DIR
./nheqminer -v -l "${PoolHost}":"${Port}" -u "${PublicVerusCoinAddress}"."${WorkerName}" -t "${Threads}" "$@"
